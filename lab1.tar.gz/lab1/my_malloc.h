void *my_malloc(int size);
void *my_calloc(int num_elements, int element_size);
void my_free(void *p);
